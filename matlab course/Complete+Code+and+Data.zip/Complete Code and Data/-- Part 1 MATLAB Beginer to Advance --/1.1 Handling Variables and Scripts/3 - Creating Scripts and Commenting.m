b = 89
C = 45 

D = b + C


% this is the declaration of the variables 
b = 89;

%this is the declaration for variable c
C = 45; 

% This is the final result

D = b + C

